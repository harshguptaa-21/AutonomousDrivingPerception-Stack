
import time
import torch
from ultralytics import YOLO

IMAGE = "bus.jpg"
RUNS = 30

models = [
    ("PyTorch FP32", "yolo11n.pt"),
    ("TensorRT FP16", "yolo11n.engine"),
]

for name, path in models:
    model = YOLO(path)

    # Warm up the GPU
    for _ in range(5):
        model.predict(IMAGE, device=0, verbose=False)

    times = []

    for _ in range(RUNS):
        torch.cuda.synchronize()
        start = time.perf_counter()

        model.predict(IMAGE, device=0, verbose=False)

        torch.cuda.synchronize()
        elapsed = (time.perf_counter() - start) * 1000
        times.append(elapsed)

    avg_ms = sum(times) / len(times)
    fps = 1000 / avg_ms

    print(f"\n{name}")
    print(f"Average latency: {avg_ms:.2f} ms")
    print(f"Estimated FPS: {fps:.2f}")
